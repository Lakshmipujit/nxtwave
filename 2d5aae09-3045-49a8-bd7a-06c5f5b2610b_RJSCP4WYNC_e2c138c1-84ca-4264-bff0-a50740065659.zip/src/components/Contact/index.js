// src/components/Contact/index.js
import React from 'react'
import './index.css'

const Contact = () => {
  return (
    <div className="contact-container">
      <h1 className="contact-heading">Contact</h1>
      <img 
        src="https://assets.ccbp.in/frontend/react-js/contact-blog-img.png" 
        alt="contact" 
        className="contact-image" 
      />
      <p className="contact-description">
        Get in touch with us today!
      </p>
    </div>
  )
}

export default Contact
