// src/components/NotFound/index.js
import React from 'react'
import './index.css'

const NotFound = () => {
  return (
    <div className="not-found-container">
      <h1 className="not-found-heading">Not Found</h1>
      <p className="not-found-text">Sorry, the page you are looking for might be unavailable.</p>
      <img 
        src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png" 
        alt="not found" 
        className="not-found-image" 
      />
    </div>
  )
}

export default NotFound
