// src/components/About/index.js
// src/components/About/index.js
import React from 'react'
import './index.css'

const About = () => {
  return (
    <div className="about-container">
      <h1 className="about-heading">About</h1>
      <img 
        src="https://assets.ccbp.in/frontend/react-js/about-blog-img.png" 
        alt="about" 
        className="about-image" 
      />
      <p className="about-description">
        Learn more about our mission and vision.
      </p>
    </div>
  )
}

export default About
