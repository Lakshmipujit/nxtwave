// src/components/Home/index.js
import React from 'react'
import './index.css'

const Home = () => {
  return (
    <div className="home-container">
      <h1 className="home-heading">Home</h1>
      <img 
        src="https://assets.ccbp.in/frontend/react-js/home-blog-img.png" 
        alt="home" 
        className="home-image" 
      />
      <p className="home-description">
        Welcome to our homepage!
      </p>
    </div>
  )
}

export default Home
